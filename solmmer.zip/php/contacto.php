<?php
$string = htmlentities($string, ENT_QUOTES,'UTF-8');
	$nombre = $_POST['nombre'];
	$correo = $_POST['correo'];
	$ciudad = $_POST['ciudad'];
	$telefono = $_POST['telefono'];
	$mensaje = $_POST['mensaje'];
	if ($correo=="") {
		header ("location: http://www.google.com");
	} else {
	$sendTo = "contacto@solmmer.com.mx";
	$subject = "Mensaje enviado desde la Web";

	$headers = "From: Web<" . $correo .">\r\n";
	$headers .= "Reply-To: " . $correo . "\r\n";
	$headers .= "Return-path: " . $correo;
    $header .= "Content-Type: text/plain; charset=UTF-8";  
	$message = $message = utf8_decode ( "Nombre: ".$nombre."\n".
	"Correo: ".$correo."\n".
	"Telefono: ".$telefono."\n".
	"Ciudad: ".$ciudad."\n".
	"Mensaje: ".$mensaje."\n");
	
  
	mail( $sendTo, $subject, $message, $headers );
	header ("location: ../thank-you-page.html");
	}


?>
